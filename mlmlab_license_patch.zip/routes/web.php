<?php
use Illuminate\Support\Facades\Route;

// ✅ Bypass license screen
Route::get('/install', function () {
    return redirect('/dashboard');
});
