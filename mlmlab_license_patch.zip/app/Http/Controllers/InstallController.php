<?php
namespace App\Http\Controllers;

class InstallController extends Controller
{
    public function index()
    {
        return redirect('/dashboard'); // ✅ License skipped
    }
}
