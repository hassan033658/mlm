<?php
namespace App\Helpers;

class LicenseHelper
{
    public static function validate()
    {
        return true; // ✅ License always valid
    }
}
